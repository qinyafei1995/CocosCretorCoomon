"use strict";
cc._RF.push(module, 'c18eeyol5JAmYNj6Bzx3m5Z', 'play_ctrl');
// scripts/play_ctrl.js

"use strict";

var nav_agent = require("nav_agent");

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },

        player: {
            type: nav_agent,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on(cc.Node.EventType.TOUCH_START, function (e) {
            var w_pos = e.getLocation();
            this.player.nav_to_map(w_pos);
        }.bind(this));
    }
}

// update (dt) {},
);

cc._RF.pop();