(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/game_app.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '5a557FJhWBEiq1EAHvctLBb', 'game_app', __filename);
// scripts/game_app.js

"use strict";

var UI_manager = require("UI_manager");
cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        // 初始化其它的全局框架模块
        // end ;
    },
    start: function start() {
        this.enter_login_scene();
    },


    // 编写代码来new login场景数据;
    enter_login_scene: function enter_login_scene() {
        // 创建地图，释放怪物

        // end 

        // 生成UI视图
        UI_manager.show_ui_at(this.node, "LoginUI");
        // end 
    },
    update: function update(dt) {}
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=game_app.js.map
        